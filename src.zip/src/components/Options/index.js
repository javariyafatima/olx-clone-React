function Options (props){
    return<>
        {
            props.data.map(item=>{
                return item
            })
        }
    </>
}

export default Options